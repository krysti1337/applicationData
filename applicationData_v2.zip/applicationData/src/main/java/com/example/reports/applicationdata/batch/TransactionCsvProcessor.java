package com.example.reports.applicationdata.batch;

import com.example.reports.applicationdata.model.*;
import lombok.Getter;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;

@Component
public class TransactionCsvProcessor implements ItemProcessor<TransactionCsvRecord, Transaction> {

    @Getter
    private final Set<Customer> customers = new HashSet<>();

    @Getter
    private final Set<Product> products = new HashSet<>();

    @Override
    public Transaction process(TransactionCsvRecord record) {
        Customer customer = new Customer(record.getCustomerID(), record.getCountry());
        Product product = new Product(record.getStockCode(), record.getDescription(), record.getUnitPrice());

        customers.add(customer);
        products.add(product);

        Transaction transaction = new Transaction();
        transaction.setInvoiceNo(record.getInvoiceNo());
        transaction.setQuantity(record.getQuantity());
        transaction.setInvoiceDate(LocalDateTime.parse(record.getInvoiceDate()));
        transaction.setCustomer(customer);
        transaction.setProduct(product);

        return transaction;
    }
}
