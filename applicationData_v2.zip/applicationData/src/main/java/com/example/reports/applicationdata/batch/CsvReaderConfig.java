package com.example.reports.applicationdata.batch;

import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

@Configuration
public class CsvReaderConfig {

    public FlatFileItemReader<TransactionCsvRecord> transactionCsvReader() {
        return new FlatFileItemReaderBuilder<TransactionCsvRecord> ()
                .name("transactionCsvReader")
                .resource(new ClassPathResource("transaction.csv"))
                .linesToSkip(1)
                .lineMapper(new DefaultLineMapper<TransactionCsvRecord>() {{
                    setLineTokenizer(new DelimitedLineTokenizer() {{
                        setNames("invoiceNo", "quantity", "invoiceDate", "customerId", "country", "stockCode", "description", "unitPrice");
                    }});
                    setFieldSetMapper(new BeanWrapperFieldSetMapper<>() {{
                        setTargetType(TransactionCsvRecord.class);
                    }});
                }})
                .build();
    }
}
