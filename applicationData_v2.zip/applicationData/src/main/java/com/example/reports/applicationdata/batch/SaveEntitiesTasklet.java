package com.example.reports.applicationdata.batch;


import com.example.reports.applicationdata.dao.impl.CustomerDaoImpl;
import com.example.reports.applicationdata.dao.impl.ProductDaoImpl;
import com.example.reports.applicationdata.dao.impl.TransactionDaoImpl;
import com.example.reports.applicationdata.model.Transaction;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class SaveEntitiesTasklet implements Tasklet {

    private final TransactionCsvProcessor processor;
    private final CustomerDaoImpl customerDao;
    private final ProductDaoImpl productDao;
    private final TransactionDaoImpl transactionDao;

    private final List<Transaction> bufferTransactions;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        customerDao.saveAll(processor.getCustomers());
        productDao.saveAll(processor.getProducts());
        transactionDao.saveAll((Set<Transaction>) bufferTransactions);
        return RepeatStatus.FINISHED;
    }
}