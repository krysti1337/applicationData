package com.example.reports.applicationdata.batch;

import com.example.reports.applicationdata.dao.impl.CustomerDaoImpl;
import com.example.reports.applicationdata.dao.impl.ProductDaoImpl;
import com.example.reports.applicationdata.dao.impl.TransactionDaoImpl;
import com.example.reports.applicationdata.model.Customer;
import com.example.reports.applicationdata.model.Product;
import com.example.reports.applicationdata.model.Transaction;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class MultiEntityWriter implements ItemWriter <TransactionCsvRecord>{

    private final CustomerDaoImpl customerDao;
    private final ProductDaoImpl productDao;
    private final TransactionDaoImpl transactionDao;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy H:mm");

    @Autowired
    public MultiEntityWriter(CustomerDaoImpl customerDao, ProductDaoImpl productDao, TransactionDaoImpl transactionDao) {
        this.customerDao = customerDao;
        this.productDao = productDao;
        this.transactionDao = transactionDao;
    }

    @Override
    public void write(Chunk<? extends TransactionCsvRecord> chunk) throws Exception {
        for(TransactionCsvRecord record : chunk){

            //Save customer if not exists
            Long customerId = Long.parseLong(record.getCustomerID());
            Customer customer = customerDao.findById(customerId);

            if(customer == null){
                customer = new Customer();
                customer.setCustomerId(customerId);
                customer.setCountry(record.getCountry());
                customerDao.save(customer);
            }

            //Save product if doesn't exist
            String stockCode = record.getStockCode();
            Product product = productDao.findById(stockCode);
            if(product == null){
                product = new Product();
                product.setStockCode(stockCode);
                product.setDescription(record.getDescription());
                product.setUnitPrice(record.getUnitPrice());
                productDao.save(product);
            }

            //Save transaction
            Transaction transaction = new Transaction();
            transaction.setInvoiceNo(record.getInvoiceNo());
            transaction.setQuantity(record.getQuantity());
            transaction.setInvoiceDate(LocalDateTime.parse(record.getInvoiceDate(), formatter));
            transaction.setCustomer(customer);
            transaction.setProduct(product);

            transactionDao.save(transaction);
        }
    }
}
